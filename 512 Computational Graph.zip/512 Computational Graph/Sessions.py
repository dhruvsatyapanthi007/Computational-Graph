import numpy as np
from Operation import Operation
from placeholder import placeholder
from Variable import Variable
from Constant import Constant
# importing networkx
import networkx as nx
# importing matplotlib.pyplot
import matplotlib.pyplot as plt
import Graph

class Session:
    """Represents a particular execution of a computational graph.
    """

    def run(self, operation, feed_dict={}):
        """Computes the output of an operation

        Args:
          operation: The operation whose output we'd like to compute.
          feed_dict: A dictionary that maps placeholders to values for this session
        """
        # GraphTry
        # g = nx.Graph()
        # g_var = nx.Graph()
        g = nx.DiGraph()
        g_var = nx.DiGraph()

        # Perform a post-order traversal of the graph to bring the nodes into the right order
        nodes_postorder = traverse_postorder(operation)
        nod = []
        varNod = []
        labels_dict = Graph._default_graph.names

        # Iterate all nodes to determine their value
        for node in nodes_postorder:

            if type(node) == placeholder:
                # Set the node value to the placeholder value from feed_dict
                node.output = feed_dict[node]

                # g.add_node(str(node.output))
            elif type(node) == Variable:
                # Set the node value to the variable's value attribute
                node.output = node.value

                # g.add_node(str(node.output))
            elif type(node) == Constant:
                node.output = node.value
            else:  # Operation
                # Get the input values for this operation from the output values of the input nodes
                node.inputs = [input_node.output for input_node in node.input_nodes]

                # Compute the output of this operation
                node.output = node.compute(*node.inputs)
                
                t = [labels_dict[node.__name__], node.output]
                nod.append((node.inputs, t))

                varNod.append(([input_node.__name__ for input_node in node.input_nodes], node.__name__))

                # print(node)

            # Convert lists to numpy arrays
            if type(node.output) == list:
                node.output = np.array(node.output)

        
 
        print(nod)
        f1_label_dict = {}
        for i in range(0,len(nod)):
            f1_label_dict[str(nod[i][0][0])] = str(nod[i][0][0])
            f1_label_dict[str(nod[i][0][1])] = str(nod[i][0][1])
            f1_label_dict[str(nod[i][1][0])+'_'+str(i)] = str(nod[i][1][0])
            f1_label_dict[str(nod[i][1][1])] = str(nod[i][1][1])
            g.add_edge(str(nod[i][0][0]), str(nod[i][1][0])+'_'+str(i))
            g.add_edge(str(nod[i][0][1]), str(nod[i][1][0])+'_'+str(i))
            # g.add_edge(str(nod[i][0]), str(nod[i+1][0]))
            # g.add_edge(str(nod[i][1]), str(nod[i+1][0]))
            g.add_edge(str(nod[i][1][0]+'_'+str(i)), str(nod[i][1][1]))
            
            # g_var.add_edge(str(nod[i][0]), str(nod[i+1][0]+'_'+str(i)))
            # g_var.add_edge(str(nod[i][1]), str(nod[i+1][0])+'_'+str(i))
            # g_var.add_edge(str(nod[i+1][0]+'_'+str(i)), str(nod[i+1][1]))
            g_var.add_edge(str(varNod[i][0][0]), str(varNod[i][-1]))
            g_var.add_edge(str(varNod[i][0][1]), str(varNod[i][-1]))
            # g_var.add_edge(str(varNod[i+1][0]), str(varNod[i+1][1]))
        nx.draw(g, labels=f1_label_dict, with_labels = True, connectionstyle='arc3, rad = 0.1')
        plt.savefig("filename.png")
        plt.clf()
        nx.draw(g_var, labels=labels_dict, with_labels = True, connectionstyle='arc3, rad = 0.1')
        plt.savefig("filename2.png")
        # Return the requested node value
        return operation.output


def traverse_postorder(operation):
    """Performs a post-order traversal, returning a list of nodes
    in the order in which they have to be computed

    Args:
       operation: The operation to start traversal at
    """

    nodes_postorder = []

    def recurse(node):
        if isinstance(node, Operation):
            for input_node in node.input_nodes:
                recurse(input_node)
        nodes_postorder.append(node)

    recurse(operation)
    return nodes_postorder