import Graph

class Variable:
    """Represents a variable (i.e. an intrinsic, changeable parameter of a computational graph).
    """
    nameGiven = ''

    def __init__(self, initial_value=None, namePassed=''):
        """Construct Variable

        Args:
          initial_value: The initial value of this variable
        """
        self.value = initial_value
        self.consumers = []
        self.__name__ = namePassed

        # Append this variable to the list of variables in the currently active default graph
        Graph._default_graph.variables.append(self)
        Graph._default_graph.names[self.__name__] = self.__name__
