import Graph

class Constant:
    """Represents a constant (i.e. an intrinsic, changeable parameter of a computational graph).
    """
    nameGiven = ''

    def __init__(self, initial_value=None):
        """Construct constant

        Args:
          initial_value: The initial value of this Constant
        """
        self.value = initial_value
        self.consumers = []
        self.__name__ = str(round(self.value, 2))

        # Append this constant to the list of Constants in the currently active default graph
        Graph._default_graph.variables.append(self)
        Graph._default_graph.names[self.__name__] = self.__name__
