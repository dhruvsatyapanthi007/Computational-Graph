from Operation import Operation
import numpy as np


#-MANAN START----------------------------
#SCALAR OPERATIONS add, sub, mul, div, modulo, power

class sub(Operation):
    def __init__(self, x, y):        
        super().__init__([x, y])

    def compute(self, x_value, y_value):
        return x_value - y_value

# mul, div, modulo, power
class mul(Operation):
    def __init__(self, x, y):
        super().__init__([x, y])

    def compute(self, x_value, y_value):
        return x_value * y_value

# mul, div, modulo, power
class div(Operation):
    def __init__(self, x, y):
        super().__init__([x, y])

    def compute(self, x_value, y_value):
        return x_value / y_value

# modulo, power
class modulo(Operation):
    def __init__(self, x, y):
        super().__init__([x, y])
        
    def compute(self, x_value, y_value):
        return x_value % y_value

# power
class power(Operation):
    def __init__(self, x, y):
        super().__init__([x, y])

    def compute(self, x_value, y_value):
        return x_value ** y_value

#SCALAR OPERATIONS 

#MATRIX OPERATION
#MATRIX ADD and Subtract
# class matAdd(Operation):
#     def __init__(self, a, b):
#         super().__init__([a, b])

#     def compute(self, a_value, b_value):
#         return np.add(a_value,b_value)

# class matSub(Operation):
#     def __init__(self, a, b):
#         super().__init__([a, b])

#     def compute(self, a_value, b_value):
#         return np.subtract(a_value,b_value)

class matTranspose(Operation):
    a_name = ''
    def __init__(self, a, b):
        super().__init__([a, b])

    def compute(self, a_value):
        return np.transpose(a_value)

class matInversion(Operation):
    a_name = ''
    def __init__(self, a, b):
        super().__init__([a, b])

    def compute(self, a_value):
        return np.linalg.inv(a_value)

class matmul(Operation):
    def __init__(self, a, b):
        super().__init__([a, b])

    def compute(self, a_value, b_value):
        return a_value.dot(b_value)

class add(Operation):
    def __init__(self, x, y):
        super().__init__([x, y])
        
    def compute(self, x_value, y_value):
        return (x_value - y_value)

#MATRIX OPERATION
#-MANAN END----------------------------